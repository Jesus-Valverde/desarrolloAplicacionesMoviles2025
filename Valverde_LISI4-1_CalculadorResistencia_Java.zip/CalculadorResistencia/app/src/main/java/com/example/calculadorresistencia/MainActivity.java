package com.example.calculadorresistencia; // Asegúrate que este sea tu paquete

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity { // Nombre de clase cambiado a MainActivity

    private RadioGroup radioGroupBands;
    private Button btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main); // Cambiado a activity_main

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        radioGroupBands = findViewById(R.id.radioGroupBands);
        btnContinue = findViewById(R.id.btnContinue);

        btnContinue.setOnClickListener(view -> {
            int selectedId = radioGroupBands.getCheckedRadioButtonId();

            if (selectedId == -1) {
                Toast.makeText(MainActivity.this, "Por favor, seleccione una opción", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton selectedRadioButton = findViewById(selectedId);
            String selectedOptionText = selectedRadioButton.getText().toString();
            int numberOfBands = 4;

            if (selectedOptionText.contains("4")) {
                numberOfBands = 4;
            } else if (selectedOptionText.contains("5")) {
                numberOfBands = 5;
            } else if (selectedOptionText.contains("6")) {
                numberOfBands = 6;
            }

            // Iniciar ActividadCalcularResistencia y pasar el número de bandas
            Intent intent = new Intent(MainActivity.this, ActividadCalcularResistencia.class); // Nombre de actividad en español
            intent.putExtra("NUMERO_DE_BANDAS", numberOfBands); // Clave en español
            startActivity(intent);
        });
    }
}
