package com.example.calculadorresistencia; // Asegúrate que este sea tu paquete

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Locale;
import java.text.DecimalFormat;


public class ActividadCalcularResistencia extends AppCompatActivity { // Nombre de clase en español

    private TextView tvResistanceValue;
    private Spinner spinnerBand1, spinnerBand2, spinnerBand3, spinnerBand4, spinnerBand5, spinnerBand6;
    private TextView tvBand3Label, tvBand4Label, tvBand5Label, tvBand6Label;
    private LinearLayout band3Container, band4Container, band5Container, band6Container;
    private Button btnBack;

    private int numeroDeBandas; // Variable en español

    // Mapeo de colores a valores
    private final HashMap<String, Integer> digitValues = new HashMap<>();
    private final HashMap<String, Double> multiplierValues = new HashMap<>();
    private final HashMap<String, Double> toleranceValues = new HashMap<>();
    private final HashMap<String, Integer> ppmValues = new HashMap<>();

    // Arrays de colores para los Spinners
    private final String[] digitColors = {"Negro (0)", "Marrón (1)", "Rojo (2)", "Naranja (3)", "Amarillo (4)", "Verde (5)", "Azul (6)", "Violeta (7)", "Gris (8)", "Blanco (9)"};
    private final String[] multiplierColors = {"Negro (x1)", "Marrón (x10)", "Rojo (x100)", "Naranja (x1k)", "Amarillo (x10k)", "Verde (x100k)", "Azul (x1M)", "Violeta (x10M)", "Gris (x100M)", "Blanco (x1G)", "Oro (x0.1)", "Plata (x0.01)"};
    private final String[] toleranceColors = {"Marrón (±1%)", "Rojo (±2%)", "Verde (±0.5%)", "Azul (±0.25%)", "Violeta (±0.1%)", "Gris (±0.05%)", "Oro (±5%)", "Plata (±10%)", "Ninguno (±20%)"};
    private final String[] ppmColors = {"Marrón (100ppm)", "Rojo (50ppm)", "Naranja (15ppm)", "Amarillo (25ppm)", "Verde (20ppm)", "Azul (10ppm)", "Violeta (5ppm)", "Gris (1ppm)"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular_resistencia); // Layout en español

        numeroDeBandas = getIntent().getIntExtra("NUMERO_DE_BANDAS", 4); // Clave en español

        initializeViews();
        initializeColorMaps();
        setupSpinners();
        updateBandVisibilityAndLabels();

        btnBack.setOnClickListener(v -> finish());
    }

    private void initializeViews() {
        tvResistanceValue = findViewById(R.id.tvResistanceValue);
        spinnerBand1 = findViewById(R.id.spinnerBand1);
        spinnerBand2 = findViewById(R.id.spinnerBand2);
        spinnerBand3 = findViewById(R.id.spinnerBand3);
        spinnerBand4 = findViewById(R.id.spinnerBand4);
        spinnerBand5 = findViewById(R.id.spinnerBand5);
        spinnerBand6 = findViewById(R.id.spinnerBand6);

        tvBand3Label = findViewById(R.id.tvBand3Label);
        tvBand4Label = findViewById(R.id.tvBand4Label);
        tvBand5Label = findViewById(R.id.tvBand5Label);
        tvBand6Label = findViewById(R.id.tvBand6Label);

        band3Container = findViewById(R.id.band3Container);
        band4Container = findViewById(R.id.band4Container);
        band5Container = findViewById(R.id.band5Container);
        band6Container = findViewById(R.id.band6Container);

        btnBack = findViewById(R.id.btnBack);
    }

    private void initializeColorMaps() {
        digitValues.put("Negro (0)", 0); digitValues.put("Marrón (1)", 1); digitValues.put("Rojo (2)", 2);
        digitValues.put("Naranja (3)", 3); digitValues.put("Amarillo (4)", 4); digitValues.put("Verde (5)", 5);
        digitValues.put("Azul (6)", 6); digitValues.put("Violeta (7)", 7); digitValues.put("Gris (8)", 8);
        digitValues.put("Blanco (9)", 9);

        multiplierValues.put("Negro (x1)", 1.0); multiplierValues.put("Marrón (x10)", 10.0);
        multiplierValues.put("Rojo (x100)", 100.0); multiplierValues.put("Naranja (x1k)", 1000.0);
        multiplierValues.put("Amarillo (x10k)", 10000.0); multiplierValues.put("Verde (x100k)", 100000.0);
        multiplierValues.put("Azul (x1M)", 1000000.0); multiplierValues.put("Violeta (x10M)", 10000000.0);
        multiplierValues.put("Gris (x100M)", 100000000.0); multiplierValues.put("Blanco (x1G)", 1000000000.0);
        multiplierValues.put("Oro (x0.1)", 0.1); multiplierValues.put("Plata (x0.01)", 0.01);

        toleranceValues.put("Marrón (±1%)", 1.0); toleranceValues.put("Rojo (±2%)", 2.0);
        toleranceValues.put("Verde (±0.5%)", 0.5); toleranceValues.put("Azul (±0.25%)", 0.25);
        toleranceValues.put("Violeta (±0.1%)", 0.1); toleranceValues.put("Gris (±0.05%)", 0.05);
        toleranceValues.put("Oro (±5%)", 5.0); toleranceValues.put("Plata (±10%)", 10.0);
        toleranceValues.put("Ninguno (±20%)", 20.0);

        ppmValues.put("Marrón (100ppm)", 100); ppmValues.put("Rojo (50ppm)", 50);
        ppmValues.put("Naranja (15ppm)", 15); ppmValues.put("Amarillo (25ppm)", 25);
        ppmValues.put("Verde (20ppm)", 20); ppmValues.put("Azul (10ppm)", 10);
        ppmValues.put("Violeta (5ppm)", 5); ppmValues.put("Gris (1ppm)", 1);
    }

    private ArrayAdapter<String> createAdapter(String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    private void setupSpinners() {
        spinnerBand1.setAdapter(createAdapter(digitColors));
        spinnerBand2.setAdapter(createAdapter(digitColors));

        switch (numeroDeBandas) {
            case 4:
                spinnerBand3.setAdapter(createAdapter(multiplierColors));
                spinnerBand4.setAdapter(createAdapter(toleranceColors));
                break;
            case 5:
                spinnerBand3.setAdapter(createAdapter(digitColors));
                spinnerBand4.setAdapter(createAdapter(multiplierColors));
                spinnerBand5.setAdapter(createAdapter(toleranceColors));
                break;
            case 6:
                spinnerBand3.setAdapter(createAdapter(digitColors));
                spinnerBand4.setAdapter(createAdapter(multiplierColors));
                spinnerBand5.setAdapter(createAdapter(toleranceColors));
                spinnerBand6.setAdapter(createAdapter(ppmColors));
                break;
        }
        AdapterView.OnItemSelectedListener autoCalculateListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculateAndDisplayResistance();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        spinnerBand1.setOnItemSelectedListener(autoCalculateListener);
        spinnerBand2.setOnItemSelectedListener(autoCalculateListener);
        spinnerBand3.setOnItemSelectedListener(autoCalculateListener);
        spinnerBand4.setOnItemSelectedListener(autoCalculateListener);
        spinnerBand5.setOnItemSelectedListener(autoCalculateListener);
        spinnerBand6.setOnItemSelectedListener(autoCalculateListener);

    }

    private void updateBandVisibilityAndLabels() {
        band3Container.setVisibility(View.VISIBLE);
        band4Container.setVisibility(View.VISIBLE);
        band5Container.setVisibility(View.GONE);
        band6Container.setVisibility(View.GONE);

        switch (numeroDeBandas) {
            case 4:
                tvBand3Label.setText("Banda 3 (Mult.):");
                tvBand4Label.setText("Banda 4 (Tol.):");
                break;
            case 5:
                tvBand3Label.setText("Banda 3 (Dígito):");
                tvBand4Label.setText("Banda 4 (Mult.):");
                tvBand5Label.setText("Banda 5 (Tol.):");
                band5Container.setVisibility(View.VISIBLE);
                break;
            case 6:
                tvBand3Label.setText("Banda 3 (Dígito):");
                tvBand4Label.setText("Banda 4 (Mult.):");
                tvBand5Label.setText("Banda 5 (Tol.):");
                tvBand6Label.setText("Banda 6 (PPM):");
                band5Container.setVisibility(View.VISIBLE);
                band6Container.setVisibility(View.VISIBLE);
                break;
        }
    }

    private void calculateAndDisplayResistance() {
        try {
            long valDigit1 = digitValues.get(spinnerBand1.getSelectedItem().toString());
            long valDigit2 = digitValues.get(spinnerBand2.getSelectedItem().toString());
            long valDigit3 = 0;
            double valMultiplier = 1;
            String toleranceStr = "";
            String ppmStr = "";

            switch (numeroDeBandas) {
                case 4:
                    valMultiplier = multiplierValues.get(spinnerBand3.getSelectedItem().toString());
                    toleranceStr = spinnerBand4.getSelectedItem().toString().split("\\(")[1].replace(")", "");
                    break;
                case 5:
                    valDigit3 = digitValues.get(spinnerBand3.getSelectedItem().toString());
                    valMultiplier = multiplierValues.get(spinnerBand4.getSelectedItem().toString());
                    toleranceStr = spinnerBand5.getSelectedItem().toString().split("\\(")[1].replace(")", "");
                    break;
                case 6:
                    valDigit3 = digitValues.get(spinnerBand3.getSelectedItem().toString());
                    valMultiplier = multiplierValues.get(spinnerBand4.getSelectedItem().toString());
                    toleranceStr = spinnerBand5.getSelectedItem().toString().split("\\(")[1].replace(")", "");
                    ppmStr = spinnerBand6.getSelectedItem().toString().split("\\(")[1].replace("ppm)", " PPM");
                    break;
            }

            double baseValue;
            if (numeroDeBandas == 4) {
                baseValue = (valDigit1 * 10 + valDigit2);
            } else {
                baseValue = (valDigit1 * 100 + valDigit2 * 10 + valDigit3);
            }

            double resistance = baseValue * valMultiplier;

            String formattedResistance;
            DecimalFormat df = new DecimalFormat("#.##");

            if (resistance >= 1_000_000_000) {
                formattedResistance = df.format(resistance / 1_000_000_000) + " GΩ";
            } else if (resistance >= 1_000_000) {
                formattedResistance = df.format(resistance / 1_000_000) + " MΩ";
            } else if (resistance >= 1_000) {
                formattedResistance = df.format(resistance / 1_000) + " kΩ";
            } else {
                formattedResistance = df.format(resistance) + " Ω";
            }

            String resultText = "R = " + formattedResistance + " " + toleranceStr;
            if (numeroDeBandas == 6 && !ppmStr.isEmpty()) {
                resultText += ", " + ppmStr;
            }
            tvResistanceValue.setText(resultText);

        } catch (Exception e) {
            tvResistanceValue.setText("R = Error");
            Toast.makeText(this, "Error al seleccionar colores: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}
