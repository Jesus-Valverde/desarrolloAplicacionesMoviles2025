package com.example.aplicacion09;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Spinner comboBox;
    private TextView txtFaseAlumno;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        comboBox = findViewById(R.id.spinnerAlumnos);
        txtFaseAlumno = findViewById(R.id.txtFaseAlumno);
        button = findViewById(R.id.button);

        String[] lista = {
                "Selecciona un Alumno",
                "Danna Paola Butchart Iribe",
                "Heber Eduardo Guzman Tapia",
                "Jose David Santana Esparza",
                "Jesus Manuel Valverde Perez",
                "Jaime Coronel Benites"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        comboBox.setAdapter(adapter);

        comboBox.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nombre = parent.getItemAtPosition(position).toString();

                if (nombre.equals("Danna Paola Butchart Iribe") || nombre.equals("Heber Eduardo Guzman Tapia")) {
                    txtFaseAlumno.setText("Redes");
                } else if (nombre.equals("Jose David Santana Esparza") || nombre.equals("Jesus Manuel Valverde Perez") || nombre.equals("Jaime Coronel Benites")) {
                    txtFaseAlumno.setText("Programación");
                } else {
                    txtFaseAlumno.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });

    }
    public void enviar(View view) {
        String nombre = comboBox.getSelectedItem().toString();
        String nombreApp = getString(R.string.app_name) + "_Valverde_Jesus";
        String asunto = "Horario de la fase - " + nombreApp;
        String fase = txtFaseAlumno.getText().toString();

        if (!nombre.equals("Selecciona un Alumno")) {
            if (!fase.isEmpty()) {
                String[][] horario;

                if (fase.equals("Programación")) {
                    horario = new String[][]{
                            {"08:00 - 08:50 AM", "Derecho Informático", "M.C Delma Lidia Mendoza Tirado"},
                            {"08:50 - 09:40 AM", "Sistemas de información geográfica", "Lic. Erik Iván Sánchez Valdez"},
                            {"09:40 - 10:30 AM", "Desarrollo de aplicaciones móviles", "Dr. Juan Jose Rodriguez Malpica Garcia"},
                            {"10:30 - 11:20 AM", "Programación de videojuegos", "Prof. Ulises Zaldívar colado"},
                            {"11:20 - 12:10 PM", "Administración de páginas web", "Dr. Juan Francisco Peraza Garzón"},
                            {"12:10 - 1:00 PM", "Interacción Hombre-Máquina", "Lic. Esteban Bernal Malagon"}
                    };
                } else {
                    horario = new String[][]{
                            {"08:00 - 08:50 AM", "Derecho Informático", "M.C Delma Lidia Mendoza Tirado"},
                            {"08:50 - 09:40 AM", "Innovaciones Tecnológicas", "Dr. Jose Alfonso Aguilar Calderon"},
                            {"09:40 - 10:30 AM", "Desarrollo de Aplicaciones Móviles", "M.C Juan Jose Rodriguez Malpica Garcia"},
                            {"10:30 - 11:20 AM", "Sistemas Operativos", "Lic. Alan Segura Rojo"},
                            {"11:20 - 12:10 PM", "Telemática 2", "Lic. Esteban Bernal"},
                            {"12:10 - 1:00 PM", "Interacción Hombre-Máquina", "Lic. Esteban Bernal"}
                    };
                }

                // Convertir la matriz a un String con formato
                StringBuilder mensaje = new StringBuilder();
                mensaje.append("Hola,\n\nEste es el horario de la fase de ").append(nombre).append(":\n\n");

                for (String[] fila : horario) {
                    mensaje.append(fila[0]).append(" - ").append(fila[1]).append(" (").append(fila[2]).append(")\n");
                }

                mensaje.append("\nSaludos,\n").append(nombreApp);

                // Intent para enviar el correo
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("message/rfc822");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"jesusvalverde05@gmail.com"});
                intent.putExtra(Intent.EXTRA_SUBJECT, asunto);
                intent.putExtra(Intent.EXTRA_TEXT, mensaje.toString());

                try {
                    startActivity(Intent.createChooser(intent, "Enviar correo con..."));
                } catch (android.content.ActivityNotFoundException e) {
                    Toast.makeText(this, "No hay aplicaciones de correo instaladas.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "No hay fase asignada", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Por favor selecciona un integrante", Toast.LENGTH_SHORT).show();
        }
    }

}