package com.example.cardview;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "computadoras")
public class Computadora {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "nombre_equipo")
    public String nombreEquipo;

    @ColumnInfo(name = "nombre_usuario")
    public String nombreUsuario;

    @ColumnInfo(name = "direccion_ip")
    public String direccionIp;

    public Computadora() {}

    public Computadora(String nombreEquipo, String nombreUsuario, String direccionIp) {
        this.nombreEquipo = nombreEquipo;
        this.nombreUsuario = nombreUsuario;
        this.direccionIp = direccionIp;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombreEquipo() { return nombreEquipo; }
    public void setNombreEquipo(String nombreEquipo) { this.nombreEquipo = nombreEquipo; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getDireccionIp() { return direccionIp; }
    public void setDireccionIp(String direccionIp) { this.direccionIp = direccionIp; }
}
    