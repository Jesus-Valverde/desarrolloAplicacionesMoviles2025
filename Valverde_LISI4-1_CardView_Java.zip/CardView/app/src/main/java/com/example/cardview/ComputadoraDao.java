package com.example.cardview;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Delete;
import java.util.List;

@Dao
public interface ComputadoraDao {
    @Insert
    void insert(Computadora computadora);

    @Query("SELECT * FROM computadoras ORDER BY nombre_equipo ASC")
    List<Computadora> getAllComputadoras();

    @Query("SELECT * FROM computadoras WHERE id = :idComputadora")
    Computadora getComputadoraById(int idComputadora);

    @Update
    void update(Computadora computadora);

    @Delete
    void delete(Computadora computadora);

    @Query("DELETE FROM computadoras")
    void deleteAllComputadoras();
}
    