package com.example.cardview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ListadoActivity extends AppCompatActivity {

    private RecyclerView recyclerViewComputadoras;
    private ComputadoraAdapter computadoraAdapter;
    private AppDatabase db;
    private ExecutorService databaseReadExecutor;
    private TextView tvListaVacia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado);

        db = AppDatabase.getInstance(getApplicationContext());
        databaseReadExecutor = Executors.newSingleThreadExecutor();

        tvListaVacia = findViewById(R.id.tvListaVacia);
        recyclerViewComputadoras = findViewById(R.id.recyclerViewComputadoras);
        recyclerViewComputadoras.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewComputadoras.setHasFixedSize(true);

        computadoraAdapter = new ComputadoraAdapter();
        recyclerViewComputadoras.setAdapter(computadoraAdapter);

        Button btnRegresarListado = findViewById(R.id.btnRegresarListado);
        btnRegresarListado.setOnClickListener(v -> finish());
    }

    private void cargarComputadoras() {
        databaseReadExecutor.execute(() -> {
            final List<Computadora> lista = db.computadoraDao().getAllComputadoras();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (lista == null || lista.isEmpty()) {
                    recyclerViewComputadoras.setVisibility(View.GONE);
                    tvListaVacia.setVisibility(View.VISIBLE);
                } else {
                    recyclerViewComputadoras.setVisibility(View.VISIBLE);
                    tvListaVacia.setVisibility(View.GONE);
                    computadoraAdapter.setComputadoras(lista);
                }
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarComputadoras();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseReadExecutor != null && !databaseReadExecutor.isShutdown()) {
            databaseReadExecutor.shutdown();
        }
    }
}
    