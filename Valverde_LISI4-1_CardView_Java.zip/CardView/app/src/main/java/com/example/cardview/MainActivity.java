package com.example.cardview;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText etNombreEquipo, etNombreUsuario, etDireccionIp;
    private TextInputLayout tilNombreEquipo, tilNombreUsuario, tilDireccionIp;
    private Button btnRegistrarComputadora, btnVerListado;
    private AppDatabase db;
    private ExecutorService databaseWriteExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(getApplicationContext());
        databaseWriteExecutor = Executors.newSingleThreadExecutor();

        tilNombreEquipo = findViewById(R.id.tilNombreEquipo);
        etNombreEquipo = findViewById(R.id.etNombreEquipo);
        tilNombreUsuario = findViewById(R.id.tilNombreUsuario);
        etNombreUsuario = findViewById(R.id.etNombreUsuario);
        tilDireccionIp = findViewById(R.id.tilDireccionIp);
        etDireccionIp = findViewById(R.id.etDireccionIp);
        btnRegistrarComputadora = findViewById(R.id.btnRegistrarComputadora);
        btnVerListado = findViewById(R.id.btnVerListado);

        btnRegistrarComputadora.setOnClickListener(v -> registrarComputadora());
        btnVerListado.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListadoActivity.class);
            startActivity(intent);
        });
    }

    private boolean validarCampos(String nombreEquipo, String nombreUsuario, String direccionIp) {
        boolean esValido = true;
        if (TextUtils.isEmpty(nombreEquipo)) {
            tilNombreEquipo.setError("El nombre del equipo es requerido");
            esValido = false;
        } else {
            tilNombreEquipo.setError(null);
        }

        if (TextUtils.isEmpty(nombreUsuario)) {
            tilNombreUsuario.setError("El nombre del usuario es requerido");
            esValido = false;
        } else {
            tilNombreUsuario.setError(null);
        }

        if (TextUtils.isEmpty(direccionIp)) {
            tilDireccionIp.setError("La dirección IP es requerida");
            esValido = false;
        } else if (!Patterns.IP_ADDRESS.matcher(direccionIp).matches()) {
            tilDireccionIp.setError("Formato de IP inválido");
            esValido = false;
        } else {
            tilDireccionIp.setError(null);
        }
        return esValido;
    }

    private void registrarComputadora() {
        String nombreEquipo = etNombreEquipo.getText().toString().trim();
        String nombreUsuario = etNombreUsuario.getText().toString().trim();
        String direccionIp = etDireccionIp.getText().toString().trim();

        if (!validarCampos(nombreEquipo, nombreUsuario, direccionIp)) {
            return;
        }

        Computadora computadora = new Computadora(nombreEquipo, nombreUsuario, direccionIp);

        databaseWriteExecutor.execute(() -> {
            db.computadoraDao().insert(computadora);
            new Handler(Looper.getMainLooper()).post(() -> {
                Toast.makeText(MainActivity.this, "Computadora registrada exitosamente", Toast.LENGTH_SHORT).show();
                etNombreEquipo.setText("");
                etNombreUsuario.setText("");
                etDireccionIp.setText("");
                tilNombreEquipo.setError(null);
                tilNombreUsuario.setError(null);
                tilDireccionIp.setError(null);
                etNombreEquipo.requestFocus();
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseWriteExecutor != null && !databaseWriteExecutor.isShutdown()) {
            databaseWriteExecutor.shutdown();
        }
    }
}
    