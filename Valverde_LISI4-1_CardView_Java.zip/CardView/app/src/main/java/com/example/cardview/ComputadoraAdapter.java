package com.example.cardview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ComputadoraAdapter extends RecyclerView.Adapter<ComputadoraAdapter.ComputadoraViewHolder> {

    private List<Computadora> listaComputadoras = new ArrayList<>();

    @NonNull
    @Override
    public ComputadoraViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_computadora, parent, false);
        return new ComputadoraViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ComputadoraViewHolder holder, int position) {
        Computadora computadoraActual = listaComputadoras.get(position);
        holder.tvNombreEquipo.setText(computadoraActual.getNombreEquipo());
        if (computadoraActual.getNombreUsuario() != null) {
            holder.tvNombreUsuario.setText("Usuario: " + computadoraActual.getNombreUsuario());
        } else {
            holder.tvNombreUsuario.setText("Usuario: N/A");
        }
        if (computadoraActual.getDireccionIp() != null) {
            holder.tvDireccionIp.setText("IP: " + computadoraActual.getDireccionIp());
        } else {
            holder.tvDireccionIp.setText("IP: N/A");
        }
        holder.ivComputadoraIcono.setImageResource(R.drawable.ic_computer); // Asegúrate que este drawable exista
    }

    @Override
    public int getItemCount() {
        return listaComputadoras.size();
    }

    public void setComputadoras(List<Computadora> computadoras) {
        if (computadoras != null) {
            this.listaComputadoras = computadoras;
        } else {
            this.listaComputadoras.clear();
        }
        notifyDataSetChanged();
    }

    public Computadora getComputadoraAt(int position) {
        if (position >= 0 && position < listaComputadoras.size()) {
            return listaComputadoras.get(position);
        }
        return null;
    }

    class ComputadoraViewHolder extends RecyclerView.ViewHolder {
        private TextView tvNombreEquipo;
        private TextView tvNombreUsuario;
        private TextView tvDireccionIp;
        private ImageView ivComputadoraIcono;

        public ComputadoraViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreEquipo = itemView.findViewById(R.id.tvNombreEquipo);
            tvNombreUsuario = itemView.findViewById(R.id.tvNombreUsuario);
            tvDireccionIp = itemView.findViewById(R.id.tvDireccionIp);
            ivComputadoraIcono = itemView.findViewById(R.id.ivComputadoraIcono);
        }
    }
}
    