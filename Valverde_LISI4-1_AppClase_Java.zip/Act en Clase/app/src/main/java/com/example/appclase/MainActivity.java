package com.example.appclase; // Asegúrate que este sea tu paquete correcto

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.LinkedHashMap; // Usar LinkedHashMap para mantener el orden de inserción
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private Spinner spinnerColor;
    private ImageView ledImage;
    private SeekBar seekBarBrightness;
    private TextView textViewVoltageInfo;

    private String currentSelectedColorName;

    // Mapa de colores con sus datos. Usamos LinkedHashMap para mantener el orden en el Spinner.
    // R.drawable.ledapagado es la imagen que se usará como base para el LED.
    private final Map<String, ColorData> colorDataMap = new LinkedHashMap<String, ColorData>() {{
        put("Rojo", new ColorData("#FF0000", 1.8f, 2.2f));
        put("Verde", new ColorData("#00FF00", 2.0f, 3.0f));
        put("Amarillo", new ColorData("#FFFF00", 2.1f, 2.5f));
        put("Naranja", new ColorData("#FFA500", 2.0f, 2.4f));
        put("Azul", new ColorData("#0000FF", 3.0f, 3.6f));
        put("Violeta", new ColorData("#8A2BE2", 3.2f, 3.8f));
        put("Blanco", new ColorData("#FFFFFF", 3.0f, 3.6f));
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Referencia al XML layout

        // Inicialización de vistas
        spinnerColor = findViewById(R.id.spinner);
        ledImage = findViewById(R.id.ledImage);
        seekBarBrightness = findViewById(R.id.seekBarBrightness);
        textViewVoltageInfo = findViewById(R.id.textViewVoltageInfo);

        // Configuración del Spinner
        String[] colorNames = colorDataMap.keySet().toArray(new String[0]);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, colorNames
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerColor.setAdapter(adapter);

        if (colorNames.length > 0) {
            currentSelectedColorName = colorNames[0];
        }

        spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentSelectedColorName = parent.getItemAtPosition(position).toString();
                updateLedState();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No se necesita acción aquí
            }
        });

        seekBarBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    updateLedState();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No se necesita acción aquí
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No se necesita acción aquí
            }
        });

        updateLedState();
    }

    /**
     * Actualiza la apariencia del LED (color y brillo) y la información de voltaje.
     * Utiliza R.drawable.ledapagado como imagen base para ambos estados (encendido y apagado).
     */
    private void updateLedState() {
        if (currentSelectedColorName == null || !colorDataMap.containsKey(currentSelectedColorName)) {
            ledImage.setImageResource(R.drawable.ledapagado);
            ledImage.clearColorFilter();
            ledImage.setImageAlpha(255); // Completamente opaco
            textViewVoltageInfo.setText("Seleccione un color");
            return;
        }

        ColorData data = colorDataMap.get(currentSelectedColorName);
        int brightness = seekBarBrightness.getProgress();

        if (data != null) {
            textViewVoltageInfo.setText(String.format(
                    java.util.Locale.US,
                    "%s: Vmin=%.1fV, Vmax=%.1fV",
                    currentSelectedColorName, data.vmin, data.vmax
            ));

            // Siempre usamos ledapagado como la imagen base.
            ledImage.setImageResource(R.drawable.ledapagado);

            if (brightness == 0) {
                // Si el brillo es 0, mostrar el LED apagado (sin tinte, completamente opaco)
                ledImage.clearColorFilter();
                ledImage.setImageAlpha(255);
            } else {
                // Si el brillo es > 0, teñir la imagen ledapagado y ajustar alfa para brillo
                ledImage.setColorFilter(Color.parseColor(data.hexCode), PorterDuff.Mode.SRC_IN);

                int alpha = (int) (brightness * 2.55f);
                ledImage.setImageAlpha(alpha);
            }
        }
    }

    /**
     * Clase interna para almacenar los datos de cada color de LED.
     */
    private static class ColorData {
        String hexCode;
        float vmin;
        float vmax;

        ColorData(String hexCode, float vmin, float vmax) {
            this.hexCode = hexCode;
            this.vmin = vmin;
            this.vmax = vmax;
        }
    }
}
