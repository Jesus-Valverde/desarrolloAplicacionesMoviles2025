package com.example.demobdroom; // Asegúrate que este sea tu paquete

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;
import java.util.List;

@Dao
public interface AlumnoDao {
    @Insert
    void insert(Alumno alumno);

    @Query("SELECT * FROM alumnos ORDER BY nombre ASC") // Ordenar por nombre
    List<Alumno> getAllAlumnos();
}
