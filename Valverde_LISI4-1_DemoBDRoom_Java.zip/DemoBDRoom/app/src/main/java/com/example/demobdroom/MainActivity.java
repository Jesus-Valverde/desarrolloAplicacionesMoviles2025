package com.example.demobdroom; // Asegúrate que este sea tu paquete

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText etNombre, etCarrera, etGrupo;
    private AppDatabase db;
    private ExecutorService databaseWriteExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(getApplicationContext());
        databaseWriteExecutor = Executors.newSingleThreadExecutor();

        etNombre = findViewById(R.id.etNombre);
        etCarrera = findViewById(R.id.etCarrera);
        etGrupo = findViewById(R.id.etGrupo);
        Button btnGuardar = findViewById(R.id.btnGuardar);
        Button btnVerRegistros = findViewById(R.id.btnVerRegistros);

        btnGuardar.setOnClickListener(v -> guardarAlumno());

        btnVerRegistros.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });
    }

    private void guardarAlumno() {
        String nombre = etNombre.getText().toString().trim();
        String carrera = etCarrera.getText().toString().trim();
        String grupo = etGrupo.getText().toString().trim();

        // Validación para que los campos no estén vacíos
        if (TextUtils.isEmpty(nombre)) {
            etNombre.setError("El nombre es requerido");
            etNombre.requestFocus();
            Toast.makeText(this, "Por favor, ingrese el nombre.", Toast.LENGTH_SHORT).show();
            return; // Detiene la ejecución si el campo está vacío
        }
        if (TextUtils.isEmpty(carrera)) {
            etCarrera.setError("La carrera es requerida");
            etCarrera.requestFocus();
            Toast.makeText(this, "Por favor, ingrese la carrera.", Toast.LENGTH_SHORT).show();
            return; // Detiene la ejecución si el campo está vacío
        }
        if (TextUtils.isEmpty(grupo)) {
            etGrupo.setError("El grupo es requerido");
            etGrupo.requestFocus();
            Toast.makeText(this, "Por favor, ingrese el grupo.", Toast.LENGTH_SHORT).show();
            return; // Detiene la ejecución si el campo está vacío
        }

        // Si todas las validaciones pasan, procede a guardar
        Alumno alumno = new Alumno();
        alumno.nombre = nombre;
        alumno.carrera = carrera;
        alumno.grupo = grupo;

        databaseWriteExecutor.execute(() -> {
            db.alumnoDao().insert(alumno);
            new Handler(Looper.getMainLooper()).post(() -> {
                Toast.makeText(MainActivity.this, "Alumno guardado exitosamente", Toast.LENGTH_SHORT).show();
                etNombre.setText("");
                etCarrera.setText("");
                etGrupo.setText("");
                etNombre.requestFocus();
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseWriteExecutor != null && !databaseWriteExecutor.isShutdown()) {
            databaseWriteExecutor.shutdown();
        }
    }
}
