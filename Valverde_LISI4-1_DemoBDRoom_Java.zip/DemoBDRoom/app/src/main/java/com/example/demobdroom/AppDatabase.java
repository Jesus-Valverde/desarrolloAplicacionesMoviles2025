package com.example.demobdroom; // Asegúrate que este sea tu paquete

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Alumno.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract AlumnoDao alumnoDao();

    private static volatile AppDatabase INSTANCE;
    private static final String DATABASE_NAME = "escuela-db";

    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, DATABASE_NAME)
                            .fallbackToDestructiveMigration() // Para simplificar durante el desarrollo
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
