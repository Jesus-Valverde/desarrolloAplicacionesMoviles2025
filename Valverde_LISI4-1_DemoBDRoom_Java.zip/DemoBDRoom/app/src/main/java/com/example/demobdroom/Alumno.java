package com.example.demobdroom; // Asegúrate que este sea tu paquete

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "alumnos")
public class Alumno {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "nombre")
    public String nombre;

    @ColumnInfo(name = "carrera")
    public String carrera;

    @ColumnInfo(name = "grupo")
    public String grupo;
}
