package com.example.demobdroom; // Asegúrate que este sea tu paquete

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

// Importa explícitamente AlumnoAdapter
import com.example.demobdroom.AlumnoAdapter;
// Importa Alumno si no está ya implícitamente disponible (generalmente lo está si está en el mismo paquete)
// import com.example.demobdroom.Alumno;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SecondActivity extends AppCompatActivity {

    private AppDatabase db;
    private ListView lvAlumnos;
    private AlumnoAdapter adapter; // El tipo debe ser reconocido ahora
    private List<Alumno> listaAlumnosActual = new ArrayList<>();
    private ExecutorService databaseExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        db = AppDatabase.getInstance(getApplicationContext());
        databaseExecutor = Executors.newSingleThreadExecutor();

        lvAlumnos = findViewById(R.id.lvAlumnos);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        // Asegúrate que AlumnoAdapter está correctamente definido y en el mismo paquete
        // o importado correctamente.
        adapter = new AlumnoAdapter(this, listaAlumnosActual);
        lvAlumnos.setAdapter(adapter); // Esto debería funcionar si AlumnoAdapter extiende ArrayAdapter

        btnRegresar.setOnClickListener(v -> finish());

    }

    private void cargarAlumnosDesdeDb() {
        databaseExecutor.execute(() -> {
            // Asegúrate que Alumno y AlumnoDao están correctamente definidos.
            List<Alumno> alumnosObtenidos = db.alumnoDao().getAllAlumnos();
            new Handler(Looper.getMainLooper()).post(() -> {
                listaAlumnosActual.clear();
                listaAlumnosActual.addAll(alumnosObtenidos);
                adapter.notifyDataSetChanged(); // Esto debería funcionar si adapter es un ArrayAdapter
                if (listaAlumnosActual.isEmpty() && SecondActivity.this.hasWindowFocus()) {
                    // Toast.makeText(SecondActivity.this, "No hay alumnos registrados.", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        cargarAlumnosDesdeDb();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseExecutor != null && !databaseExecutor.isShutdown()) {
            databaseExecutor.shutdown();
        }
    }
}
