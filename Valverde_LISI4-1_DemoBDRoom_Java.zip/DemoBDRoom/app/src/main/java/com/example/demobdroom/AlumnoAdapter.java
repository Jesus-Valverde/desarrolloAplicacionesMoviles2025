package com.example.demobdroom; // Asegúrate que este sea tu paquete

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

// La clase AlumnoAdapter debe extender ArrayAdapter<Alumno>
public class AlumnoAdapter extends ArrayAdapter<Alumno> {

    public AlumnoAdapter(@NonNull Context context, @NonNull List<Alumno> alumnos) {
        super(context, 0, alumnos);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // Obtener el objeto Alumno para esta posición
        Alumno alumno = getItem(position);

        // ViewHolder para mejorar el rendimiento
        ViewHolder viewHolder;

        // Si la vista no se está reusando, inflarla desde el layout item_alumno.xml
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_alumno, parent, false);
            viewHolder.tvNombre = convertView.findViewById(R.id.tvItemNombre);
            viewHolder.tvCarrera = convertView.findViewById(R.id.tvItemCarrera);
            viewHolder.tvGrupo = convertView.findViewById(R.id.tvItemGrupo);
            convertView.setTag(viewHolder); // Guardar el ViewHolder en la vista
        } else {
            // Reusar el ViewHolder si la vista ya existe
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // Poblar los datos en la vista del template usando el objeto Alumno
        if (alumno != null) {
            viewHolder.tvNombre.setText(alumno.nombre);
            viewHolder.tvCarrera.setText("Carrera: " + alumno.carrera);
            viewHolder.tvGrupo.setText("Grupo: " + alumno.grupo);
        }

        // Devolver la vista completada para mostrarla en pantalla
        return convertView;
    }

    // Clase ViewHolder para almacenar las referencias a las vistas de cada ítem
    private static class ViewHolder {
        TextView tvNombre;
        TextView tvCarrera;
        TextView tvGrupo;
    }
}
