package com.example.ipcalculator;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast; // Importar para mensajes Toast
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Declaración de variables para los elementos de la UI
    private EditText ip1, ip2, ip3, ip4;
    private EditText firstOctetRange, hexIp, subnetMask, wildcardMask, subnetBits, maskBits, maxSubnets, hostsPerSubnet, hostRange, subnetId, broadcastAddress, subnetBitmap;
    private RadioGroup classGroup;
    private Button calculateBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Establece el layout de la actividad

        // Inicialización de los elementos de la UI
        classGroup = findViewById(R.id.classGroup);
        ip1 = findViewById(R.id.ip1);
        ip2 = findViewById(R.id.ip2);
        ip3 = findViewById(R.id.ip3);
        ip4 = findViewById(R.id.ip4);
        firstOctetRange = findViewById(R.id.firstOctetRange);
        hexIp = findViewById(R.id.hexIp);
        subnetMask = findViewById(R.id.subnetMask);
        wildcardMask = findViewById(R.id.wildcardMask);
        subnetBits = findViewById(R.id.subnetBits);
        maskBits = findViewById(R.id.maskBits);
        maxSubnets = findViewById(R.id.maxSubnets);
        hostsPerSubnet = findViewById(R.id.hostsPerSubnet);
        hostRange = findViewById(R.id.hostRange);
        subnetId = findViewById(R.id.subnetId);
        broadcastAddress = findViewById(R.id.broadcastAddress);
        subnetBitmap = findViewById(R.id.subnetBitmap);
        calculateBtn = findViewById(R.id.calculateBtn);

        // Listener para los RadioButtons de la clase de red
        classGroup.setOnCheckedChangeListener((group, checkedId) -> {
            // Se utiliza if-else if para evitar el error "constant expression required" con switch en algunas configuraciones.
            if (checkedId == R.id.classA) {
                firstOctetRange.setText("0-127"); // Rango para Clase A
                subnetMask.setText("255.0.0.0"); // Máscara para Clase A
            } else if (checkedId == R.id.classB) {
                firstOctetRange.setText("128-191"); // Rango para Clase B
                subnetMask.setText("255.255.0.0"); // Máscara para Clase B
            } else if (checkedId == R.id.classC) {
                firstOctetRange.setText("192-223"); // Rango para Clase C
                subnetMask.setText("255.255.255.0"); // Máscara para Clase C
            }
        });

        // Listener para el botón de calcular
        calculateBtn.setOnClickListener(v -> calculate());
    }

    // Método para realizar los cálculos de IP
    private void calculate() {
        // Validar que los campos de IP no estén vacíos
        if (TextUtils.isEmpty(ip1.getText()) || TextUtils.isEmpty(ip2.getText()) || TextUtils.isEmpty(ip3.getText()) || TextUtils.isEmpty(ip4.getText())) {
            Toast.makeText(this, "Por favor, ingresa una dirección IP completa.", Toast.LENGTH_SHORT).show(); // Mensaje de error
            return;
        }

        // Convertir los octetos de IP a enteros
        int[] ip = new int[]{
                Integer.parseInt(ip1.getText().toString()),
                Integer.parseInt(ip2.getText().toString()),
                Integer.parseInt(ip3.getText().toString()),
                Integer.parseInt(ip4.getText().toString())
        };

        // Validar que los octetos de IP estén en el rango correcto (0-255)
        for (int octet : ip) {
            if (octet < 0 || octet > 255) {
                Toast.makeText(this, "Los octetos de la IP deben estar entre 0 y 255.", Toast.LENGTH_SHORT).show(); // Mensaje de error
                return;
            }
        }

        // Obtener la máscara de subred seleccionada
        String mask = subnetMask.getText().toString();
        if (TextUtils.isEmpty(mask)) {
            Toast.makeText(this, "Por favor, selecciona una clase de red.", Toast.LENGTH_SHORT).show(); // Mensaje de error
            return;
        }

        // Calcular y mostrar la IP en hexadecimal
        hexIp.setText(String.format("%02X.%02X.%02X.%02X", ip[0], ip[1], ip[2], ip[3]));

        // Calcular y mostrar la máscara wildcard
        wildcardMask.setText(maskToWildcard(mask));

        // Calcular y mostrar los bits de subred
        subnetBits.setText(String.valueOf(countSubnetBits(mask)));

        // Calcular y mostrar los bits de máscara
        maskBits.setText(String.valueOf(countMaskBits(mask)));

        // Calcular y mostrar el número máximo de subredes
        int sBits = countSubnetBits(mask);
        maxSubnets.setText(sBits > 0 ? String.valueOf((int)Math.pow(2, sBits)) : "0");

        // Calcular y mostrar los hosts por subred
        int hBits = 32 - countMaskBits(mask);
        hostsPerSubnet.setText(String.valueOf((int)Math.pow(2, hBits) - 2)); // Se restan 2 por la dirección de red y broadcast

        // Calcular y mostrar el ID de subred
        int[] subnetIdArray = calculateSubnetId(ip, mask);
        subnetId.setText(String.format("%d.%d.%d.%d", subnetIdArray[0], subnetIdArray[1], subnetIdArray[2], subnetIdArray[3]));

        // Calcular y mostrar la dirección de broadcast
        int[] broadcastAddressArray = calculateBroadcastAddress(ip, mask);
        broadcastAddress.setText(String.format("%d.%d.%d.%d", broadcastAddressArray[0], broadcastAddressArray[1], broadcastAddressArray[2], broadcastAddressArray[3]));

        // Rango de host
        int[] firstHost = new int[4];
        int[] lastHost = new int[4];
        calculateHostRange(ip, mask, firstHost, lastHost);
        hostRange.setText(String.format("%d.%d.%d.%d - %d.%d.%d.%d", firstHost[0], firstHost[1], firstHost[2], firstHost[3], lastHost[0], lastHost[1], lastHost[2], lastHost[3]));

        // Generar y mostrar el bitmap de subred
        subnetBitmap.setText(generateBitmap(ip));
    }

    // Convierte una máscara de subred a máscara wildcard
    private String maskToWildcard(String mask) {
        String[] parts = mask.split("\\.");
        StringBuilder wildcard = new StringBuilder();
        for (String part : parts) {
            wildcard.append(255 - Integer.parseInt(part)).append(".");
        }
        return wildcard.substring(0, wildcard.length() - 1);
    }

    // Cuenta los bits de subred activos (1s) en la máscara (para clases A, B, C sin subnetting adicional)
    private int countSubnetBits(String mask) {
        // Para este programa, los bits de subred se basan en las máscaras por defecto de clase.
        // Si no hay subnetting adicional, el número de bits dedicados a subred es 0 para las máscaras de clase A, B, C por defecto.
        // Si se implementara CIDR y subnetting, esta función necesitaría más lógica.
        return 0; // Por defecto para máscaras de clase
    }

    // Cuenta todos los bits de máscara activos (1s)
    private int countMaskBits(String mask) {
        String binary = maskToBinary(mask);
        int ones = 0;
        for (char c : binary.toCharArray()) {
            if (c == '1') ones++;
        }
        return ones;
    }

    // Convierte una máscara de subred decimal a binario
    private String maskToBinary(String mask) {
        String[] parts = mask.split("\\.");
        StringBuilder binary = new StringBuilder();
        for (String part : parts) {
            binary.append(String.format("%8s", Integer.toBinaryString(Integer.parseInt(part))).replace(' ', '0'));
        }
        return binary.toString();
    }

    // Genera la representación binaria de la IP
    private String generateBitmap(int[] ip) {
        StringBuilder sb = new StringBuilder();
        for (int octet : ip) {
            sb.append(String.format("%8s", Integer.toBinaryString(octet)).replace(' ', '0')).append(" ");
        }
        return sb.toString().trim(); // Eliminar espacio final
    }

    // Calcula el ID de subred (AND bit a bit entre IP y máscara)
    private int[] calculateSubnetId(int[] ip, String mask) {
        int[] subnetId = new int[4];
        String[] maskParts = mask.split("\\.");
        for (int i = 0; i < 4; i++) {
            subnetId[i] = ip[i] & Integer.parseInt(maskParts[i]);
        }
        return subnetId;
    }

    // Calcula la dirección de broadcast (OR bit a bit entre IP y máscara wildcard)
    private int[] calculateBroadcastAddress(int[] ip, String mask) {
        int[] broadcastAddress = new int[4];
        String[] maskParts = mask.split("\\.");
        int[] wildcardParts = new int[4];
        for (int i = 0; i < 4; i++) {
            wildcardParts[i] = 255 - Integer.parseInt(maskParts[i]);
            broadcastAddress[i] = ip[i] | wildcardParts[i];
        }
        return broadcastAddress;
    }

    // Calcula el rango de direcciones de host utilizables
    private void calculateHostRange(int[] ip, String mask, int[] firstHost, int[] lastHost) {
        int[] subnetIdArray = calculateSubnetId(ip, mask);
        int[] broadcastAddressArray = calculateBroadcastAddress(ip, mask);

        // El primer host es la dirección de subred + 1 en el último octeto
        System.arraycopy(subnetIdArray, 0, firstHost, 0, 4);
        firstHost[3]++;

        // El último host es la dirección de broadcast - 1 en el último octeto
        System.arraycopy(broadcastAddressArray, 0, lastHost, 0, 4);
        lastHost[3]--;
    }
}