package com.example.aplicacion07;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.aplicacion07.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View viewElements = binding.getRoot();
        setContentView(viewElements);

    }

    public static double convertirPesosADolares(double pesos) {
        return pesos * 0.048; // Factor de conversión (ajusta según la tasa actual)
    }

    public static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    public void enviar(View view) {
        String campo = binding.campoNumero.getText().toString();

        if (!campo.isEmpty()) {
            try {
                double valor = Double.parseDouble(campo);

                if (binding.rbTemperatura.isChecked()) {
                    double resultado = celsiusToFahrenheit(valor);
                    binding.resultado.setText("" + valor + " °C = " + resultado + " °F");
                } else if (binding.rbDivisa.isChecked()) {
                    double resultado = convertirPesosADolares(valor);
                    binding.resultado.setText("$" + valor + " MXN = $" + resultado + " USD");
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Ingrese un número válido", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "El campo no puede estar vacío", Toast.LENGTH_SHORT).show();
        }
    }

}