package com.example.aplicacion03;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.v("On create", "La aplicación ha sido construida");
        Toast.makeText(this, "La aplicación ha sido construida", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("On destroy", "La aplicación se ha destruido");
        Toast.makeText(this, "La aplicación se ha destruido", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("On start", "La aplicación se ha iniciado");
        Toast.makeText(this, "La aplicación se ha iniciado", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("On stop", "La aplicación se ha detenido");
        Toast.makeText(this, "La aplicación se ha detenido", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("On pause", "La aplicación se ha pausado");
        Toast.makeText(this, "La aplicación se ha pausado", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("On resume", "La aplicación se ha reanurado");
        Toast.makeText(this, "La aplicación se ha reanurado", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v("On restart", "La aplicación se ha reiniciado");
        Toast.makeText(this, "La aplicación se ha reiniciado", Toast.LENGTH_SHORT).show();
    }
}