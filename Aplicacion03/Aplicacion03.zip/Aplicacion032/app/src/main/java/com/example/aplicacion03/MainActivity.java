package com.example.aplicacion03;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.v("On create", "La aplicación ha sido construida");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("On destroy", "La aplicación se ha destruido");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("On start", "La aplicación se ha iniciado");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("On stop", "La aplicación se ha detenido");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("On pause", "La aplicación se ha pausado");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("On resume", "La aplicación se ha reanurado");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v("On restart", "La aplicación se ha reiniciado");
    }
}