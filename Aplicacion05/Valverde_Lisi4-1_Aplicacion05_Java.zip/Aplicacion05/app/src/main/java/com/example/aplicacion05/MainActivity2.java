package com.example.aplicacion05;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String cafeResultado;
    ListView listview;
    ArrayList<String> ingredientes = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Traer las imágenes
        Resources res = getResources();
        Drawable imagenCapuchino = ResourcesCompat.getDrawable(res, R.drawable.capuchino, null);
        Drawable imagenAmericano = ResourcesCompat.getDrawable(res, R.drawable.americano, null);
        Drawable imagenCortado = ResourcesCompat.getDrawable(res, R.drawable.cortado, null);
        Drawable imagenLatte = ResourcesCompat.getDrawable(res, R.drawable.latte, null);
        Drawable imagenMocha = ResourcesCompat.getDrawable(res, R.drawable.mocha, null);

        // Conseguir los componentes de la interfaz
        TextView tvCafe = findViewById(R.id.cafe);
        ImageView imgCafe = findViewById(R.id.imageView);
        ListView listview = findViewById(R.id.lstIngredientes);

        cafeResultado = getIntent().getStringExtra("cafe");
        ingredientes = getIntent().getStringArrayListExtra("ingredientes");

        tvCafe.setText(cafeResultado);
        switch (cafeResultado){
            case "Latte" : imgCafe.setImageDrawable(imagenLatte);
                break;
            case "Mocha" : imgCafe.setImageDrawable(imagenMocha);
                break;
            case "Capuchino" : imgCafe.setImageDrawable(imagenCapuchino);
                break;
            case "Americano" : imgCafe.setImageDrawable(imagenAmericano);
                break;
            case "Cortado" : imgCafe.setImageDrawable(imagenCortado);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ingredientes);
        listview.setAdapter(adapter);
    }

    public void regresar(View view) {
        Intent intent = new Intent(MainActivity2.this, MainActivity.class);
        startActivity(intent);
    }
}