package com.example.aplicacion05;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    String cafe = "Café extravagante";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void enviar(View view){
        CheckBox cbAgua = findViewById(R.id.checkBoxAgua);
        CheckBox cbCafe = findViewById(R.id.checkBoxCafe);
        CheckBox cbLeche = findViewById(R.id.checkBoxLeche);
        CheckBox cbChocolate = findViewById(R.id.checkBoxChocolate);
        CheckBox cbVainilla = findViewById(R.id.checkBoxVainilla);
        TextView etiqueta = findViewById(R.id.title);

        if(cbAgua.isChecked() && cbCafe.isChecked() && cbLeche.isChecked()){
            cafe = "Latte";
        }

        if(cbAgua.isChecked() && cbCafe.isChecked() && cbLeche.isChecked() && cbChocolate.isChecked()) {
            cafe = "Moccha";
        }

        if(cbAgua.isChecked() && cbCafe.isChecked() && cbVainilla.isChecked() ) {
            cafe = "Capuccino";
        }

        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("cafe", cafe);
        startActivity(intent);
    }
}