package com.example.aplicacion06;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String sabriton;
    ListView listview;
    ArrayList<String> contenido = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Traer imágenes
        Resources res = getResources();
        Drawable imagenPaketaxo = ResourcesCompat.getDrawable(res, R.drawable.paketaxo, null);
        Drawable imagenQuexo = ResourcesCompat.getDrawable(res, R.drawable.quexo, null);
        Drawable imagenBotanero = ResourcesCompat.getDrawable(res, R.drawable.botanero, null);
        Drawable imagenFlaminHot = ResourcesCompat.getDrawable(res, R.drawable.flamin_hot, null);

        // Conseguir componentes
        TextView titulo = findViewById(R.id.textViewTitulo);
        ImageView imgSabriton =findViewById(R.id.ivResultado);
        ListView listview = findViewById(R.id.listContenido);

        // Conseguir información de la otra ventana
        sabriton = getIntent().getStringExtra("sabriton");
        contenido = getIntent().getStringArrayListExtra("contenido");

        // Asignar titulo e imagen del producto
        titulo.setText(sabriton);
        switch(sabriton){
            case "Mezcladito" : imgSabriton.setImageDrawable(imagenPaketaxo);
                break;
            case "Quexo" : imgSabriton.setImageDrawable(imagenQuexo);
                break;
            case "Botanero" : imgSabriton.setImageDrawable(imagenBotanero);
                break;
            case "Flamin Hot" : imgSabriton.setImageDrawable(imagenFlaminHot);
                break;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, contenido);
        listview.setAdapter(adapter);
    }

    public void regresar(View view) {
        Intent intent = new Intent(MainActivity2.this, MainActivity.class);
        startActivity(intent);
    }
}