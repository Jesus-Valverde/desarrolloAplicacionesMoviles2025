package com.example.aplicacion06;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String paketaxo = "No existe ese modelo";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void mostrarResultado(View view){
        ArrayList<String> contenido = new ArrayList<String>();
        CheckBox cbCheetosBolitas = findViewById(R.id.checkBoxCheetosBolitas);
        CheckBox cbFritos = findViewById(R.id.checkBoxFritos);
        CheckBox cbRancheritos = findViewById(R.id.checkBoxRancheritos);
        CheckBox cbSabritones = findViewById(R.id.checkBoxSabritones);
        CheckBox cbChetoosPoffs = findViewById(R.id.checkBoxCheetosPoffs);
        CheckBox cbCrujitosFlaminHot = findViewById(R.id.checkBoxCrujitosFlaminHot);
        CheckBox cbChurrumais = findViewById(R.id.checkBoxChurrumais);
        CheckBox cbSabritonesRodacas = findViewById(R.id.checkBoxSabritonesRodacas);
        CheckBox cbDoritos3d = findViewById(R.id.checkBoxDoritos3d);
        CheckBox cbCrujitos = findViewById(R.id.checkBoxCrujitos);
        CheckBox cbCheetosPalomitas = findViewById(R.id.checkBoxCheetosPalomitas);
        CheckBox cbCheetosFlaminHot = findViewById(R.id.checkBoxCheetosFlaminHot);
        CheckBox cbDoritos3dFlaminHot = findViewById(R.id.checkBoxDoritos3dFlaminHot);
        CheckBox cbTostitosFlaminHot = findViewById(R.id.checkBoxTostitosFlaminHot);
        CheckBox cbSabritonesFlaminHot = findViewById(R.id.checkBoxSabritonesFlaminHot);
        if(cbCheetosBolitas.isChecked() && cbFritos.isChecked() && cbRancheritos.isChecked() && cbSabritones.isChecked() && !cbChetoosPoffs.isChecked() && !cbCrujitosFlaminHot.isChecked() && !cbChurrumais.isChecked() && !cbSabritonesRodacas.isChecked() && !cbDoritos3d.isChecked() && !cbCrujitos.isChecked() && !cbCheetosPalomitas.isChecked() && !cbCheetosFlaminHot.isChecked() && !cbDoritos3dFlaminHot.isChecked() && !cbTostitosFlaminHot.isChecked() && !cbSabritonesFlaminHot.isChecked()){

            paketaxo = "Mezcladito";
        }

        if(!cbCheetosBolitas.isChecked() && !cbFritos.isChecked() && !cbRancheritos.isChecked() && !cbSabritones.isChecked() && cbChetoosPoffs.isChecked() && cbCrujitosFlaminHot.isChecked() && cbChurrumais.isChecked() && cbSabritonesRodacas.isChecked() && !cbDoritos3d.isChecked() && !cbCrujitos.isChecked() && !cbCheetosPalomitas.isChecked() && !cbCheetosFlaminHot.isChecked() && !cbDoritos3dFlaminHot.isChecked() && !cbTostitosFlaminHot.isChecked() && !cbSabritonesFlaminHot.isChecked()){
            paketaxo = "Botanero";
        }

        if(!cbCheetosBolitas.isChecked() && !cbFritos.isChecked() && !cbRancheritos.isChecked() && !cbSabritones.isChecked() && !cbCrujitosFlaminHot.isChecked() && !cbChurrumais.isChecked() && !cbSabritonesRodacas.isChecked() && cbDoritos3d.isChecked() && cbCrujitos.isChecked() && cbCheetosPalomitas.isChecked() && cbChetoosPoffs.isChecked() && !cbCheetosFlaminHot.isChecked() && !cbDoritos3dFlaminHot.isChecked() && !cbTostitosFlaminHot.isChecked() && !cbSabritonesFlaminHot.isChecked()){
            paketaxo = "Quexo";
        }

        if(!cbCheetosBolitas.isChecked() && !cbFritos.isChecked() && !cbRancheritos.isChecked() && !cbSabritones.isChecked() && !cbChetoosPoffs.isChecked() && !cbCrujitosFlaminHot.isChecked() && !cbChurrumais.isChecked() && !cbSabritonesRodacas.isChecked() && !cbDoritos3d.isChecked() && !cbCrujitos.isChecked() && !cbCheetosPalomitas.isChecked() && cbDoritos3dFlaminHot.isChecked() && cbCheetosFlaminHot.isChecked() && cbTostitosFlaminHot.isChecked() && cbSabritonesFlaminHot.isChecked()){
            paketaxo = "Flamin Hot";
        }

        if (cbCheetosBolitas.isChecked()){
            contenido.add("Cheetos Bolitas");
        }
        if (cbFritos.isChecked()){
            contenido.add("Fritos");
        }
        if (cbRancheritos.isChecked()){
            contenido.add("Rancheritos");
        }
        if (cbSabritones.isChecked()){
            contenido.add("Sabritones");
        }
        if (cbChetoosPoffs.isChecked()){
            contenido.add("Cheetos Poffs");
        }
        if (cbCrujitosFlaminHot.isChecked()){
            contenido.add("Crujitos Flamin Hot");
        }
        if (cbChurrumais.isChecked()){
            contenido.add("Churrumais");
        }
        if (cbSabritonesRodacas.isChecked()){
            contenido.add("Sabritones Rodacas");
        }
        if (cbDoritos3d.isChecked()){
            contenido.add("Doritos 3D");
        }
        if (cbCrujitos.isChecked()){
            contenido.add("Crujitos");
        }
        if (cbCheetosPalomitas.isChecked()){
            contenido.add("Cheetos Palomitas");
        }
        if (cbCheetosFlaminHot.isChecked()){
            contenido.add("Cheetos Flamin Hot");
        }
        if (cbDoritos3dFlaminHot.isChecked()){
            contenido.add("Doritos 3D Flamin Hot");
        }
        if (cbTostitosFlaminHot.isChecked()){
            contenido.add("Tostitos Flamin Hot");
        }
        if (cbSabritonesFlaminHot.isChecked()){
            contenido.add("Sabritones Flamin Hot");
        }

        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("contenido", contenido);
        intent.putExtra("sabriton", paketaxo);
        startActivity(intent);
    }
}