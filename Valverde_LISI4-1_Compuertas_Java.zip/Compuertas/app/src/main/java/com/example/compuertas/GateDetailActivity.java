package com.example.compuertas; // Reemplaza con tu nombre de paquete

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class GateDetailActivity extends AppCompatActivity {

    private TextView tvGateName, tvTruthTable;
    private Switch switchInputA, switchInputB;
    private ImageView ivGateSymbol, ivOutputLed;
    private LinearLayout inputBLayout;
    private String gateType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gate_detail);

        tvGateName = findViewById(R.id.tvGateName);
        tvTruthTable = findViewById(R.id.tvTruthTable);
        switchInputA = findViewById(R.id.switchInputA);
        switchInputB = findViewById(R.id.switchInputB);
        ivGateSymbol = findViewById(R.id.ivGateSymbol);
        ivOutputLed = findViewById(R.id.ivOutputLed);
        inputBLayout = findViewById(R.id.inputBLayout);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        gateType = getIntent().getStringExtra("GATE_TYPE");
        if (gateType == null) {
            gateType = "UNKNOWN";
        }

        configureGate();

        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) -> updateOutput();
        switchInputA.setOnCheckedChangeListener(listener);
        switchInputB.setOnCheckedChangeListener(listener);

        btnRegresar.setOnClickListener(v -> finish());

        updateOutput(); // Establecer estado inicial de la salida
    }

    private void configureGate() {
        tvGateName.setText("Compuerta " + gateType);
        // Asegúrate de tener estos drawables en tu carpeta res/drawable
        // o reemplázalos con los nombres correctos de tus imágenes.
        switch (gateType) {
            case "AND":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_and);
                tvTruthTable.setText("A | B | Salida\n---|---|------\n0 | 0 |   0\n0 | 1 |   0\n1 | 0 |   0\n1 | 1 |   1");
                break;
            case "OR":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_or);
                tvTruthTable.setText("A | B | Salida\n---|---|------\n0 | 0 |   0\n0 | 1 |   1\n1 | 0 |   1\n1 | 1 |   1");
                break;
            case "NOR":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_nor);
                tvTruthTable.setText("A | B | Salida\n---|---|------\n0 | 0 |   1\n0 | 1 |   0\n1 | 0 |   0\n1 | 1 |   0");
                break;
            case "NAND":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_nand);
                tvTruthTable.setText("A | B | Salida\n---|---|------\n0 | 0 |   1\n0 | 1 |   1\n1 | 0 |   1\n1 | 1 |   0");
                break;
            case "NOT":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_not);
                tvTruthTable.setText("A | Salida\n--|------\n0 |   1\n1 |   0");
                inputBLayout.setVisibility(View.GONE); // La compuerta NOT solo tiene una entrada
                break;
            case "XOR":
                ivGateSymbol.setImageResource(R.drawable.ic_gate_xor);
                tvTruthTable.setText("A | B | Salida\n---|---|------\n0 | 0 |   0\n0 | 1 |   1\n1 | 0 |   1\n1 | 1 |   0");
                break;
            default:
                tvGateName.setText("Compuerta Desconocida");
                ivGateSymbol.setImageResource(android.R.drawable.ic_menu_help); // Imagen por defecto
                tvTruthTable.setText("N/A");
                break;
        }
    }

    private void updateOutput() {
        boolean inputA = switchInputA.isChecked();
        // Para la compuerta NOT, la entrada B no es relevante y podría estar oculta.
        boolean inputB = (gateType.equals("NOT")) ? false : switchInputB.isChecked();
        boolean output = false;

        switch (gateType) {
            case "AND":
                output = inputA && inputB;
                break;
            case "OR":
                output = inputA || inputB;
                break;
            case "NOR":
                output = !(inputA || inputB);
                break;
            case "NAND":
                output = !(inputA && inputB);
                break;
            case "NOT":
                output = !inputA;
                break;
            case "XOR":
                output = inputA ^ inputB; // XOR bit a bit
                break;
        }

        if (output) {
            ivOutputLed.setImageResource(R.drawable.led_on_green);
        } else {
            ivOutputLed.setImageResource(R.drawable.led_off_red);
        }
    }
}
