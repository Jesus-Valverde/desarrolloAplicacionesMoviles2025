package com.example.compuertas; // Reemplaza con tu nombre de paquete

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnAnd).setOnClickListener(this);
        findViewById(R.id.btnOr).setOnClickListener(this);
        findViewById(R.id.btnNor).setOnClickListener(this);
        findViewById(R.id.btnNand).setOnClickListener(this);
        findViewById(R.id.btnNot).setOnClickListener(this);
        findViewById(R.id.btnXor).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String gateType = "";
        int viewId = v.getId();

        if (viewId == R.id.btnAnd) {
            gateType = "AND";
        } else if (viewId == R.id.btnOr) {
            gateType = "OR";
        } else if (viewId == R.id.btnNor) {
            gateType = "NOR";
        } else if (viewId == R.id.btnNand) {
            gateType = "NAND";
        } else if (viewId == R.id.btnNot) {
            gateType = "NOT";
        } else if (viewId == R.id.btnXor) {
            gateType = "XOR";
        }

        if (!gateType.isEmpty()) {
            Intent intent = new Intent(MainActivity.this, GateDetailActivity.class);
            intent.putExtra("GATE_TYPE", gateType);
            startActivity(intent);
        }
    }
}
