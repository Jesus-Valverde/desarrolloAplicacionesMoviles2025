package com.example.appcamara; // Asegúrate que este sea tu paquete

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DisplayActivity extends AppCompatActivity {

    private TextView tvDisplayNombre, tvDisplayApellidos, tvDisplayCorreo, tvDisplayGrupo;
    private ImageView ivDisplayFoto;
    private Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display); // Asegúrate que este layout exista

        tvDisplayNombre = findViewById(R.id.tvDisplayNombre);
        tvDisplayApellidos = findViewById(R.id.tvDisplayApellidos);
        tvDisplayCorreo = findViewById(R.id.tvDisplayCorreo);
        tvDisplayGrupo = findViewById(R.id.tvDisplayGrupo);
        ivDisplayFoto = findViewById(R.id.ivDisplayFoto);
        btnRegresar = findViewById(R.id.btnRegresar);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            tvDisplayNombre.setText(extras.getString("NOMBRE"));
            tvDisplayApellidos.setText(extras.getString("APELLIDOS"));
            tvDisplayCorreo.setText(extras.getString("CORREO"));
            tvDisplayGrupo.setText(extras.getString("GRUPO"));

            String fotoUriString = extras.getString("FOTO_URI");
            if (fotoUriString != null) {
                try {
                    Uri fotoUri = Uri.parse(fotoUriString);
                    ivDisplayFoto.setImageURI(fotoUri);
                } catch (Exception e) {
                    Toast.makeText(this, "Error al cargar la imagen: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    // Opcionalmente, poner una imagen por defecto si falla la carga
                    // ivDisplayFoto.setImageResource(R.drawable.placeholder_image);
                }
            } else {
                Toast.makeText(this, "No se proporcionó URI de imagen.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No se recibieron datos.", Toast.LENGTH_SHORT).show();
            // finish(); // Opcional: cerrar si no hay datos
        }

        btnRegresar.setOnClickListener(v -> {
            finish(); // Cierra esta actividad y regresa a la anterior (MainActivity)
        });
    }
}
