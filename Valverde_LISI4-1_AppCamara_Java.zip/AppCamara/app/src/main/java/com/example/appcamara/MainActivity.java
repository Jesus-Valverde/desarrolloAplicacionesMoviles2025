package com.example.appcamara; // Asegúrate que este sea tu paquete

import android.Manifest;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    // private static final int REQUEST_IMAGE_CAPTURE = 1; // Deprecated way

    private EditText etNombre, etApellidos, etCorreo, etGrupo;
    private ImageButton btnTomarFoto;
    private Button btnGuardar;
    private ImageView ivFotoPreview;

    private Uri fotoUri; // URI de la foto tomada
    private String currentPhotoPath; // Ruta absoluta del archivo de la foto

    // ActivityResultLauncher para la cámara
    private ActivityResultLauncher<Uri> takePictureLauncher;
    // ActivityResultLauncher para solicitar permisos
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etCorreo = findViewById(R.id.etCorreo);
        etGrupo = findViewById(R.id.etGrupo);
        btnTomarFoto = findViewById(R.id.btnTomarFoto);
        btnGuardar = findViewById(R.id.btnGuardar);
        ivFotoPreview = findViewById(R.id.ivFotoPreview);

        // Inicializar el ActivityResultLauncher para la cámara
        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                result -> {
                    if (result) { // true si la foto se tomó y guardó en la URI proporcionada
                        // La foto se guardó en fotoUri
                        ivFotoPreview.setImageURI(fotoUri);
                        ivFotoPreview.setVisibility(View.VISIBLE);
                        // Aquí podrías mostrar el diálogo "Tomar de nuevo" o "Aceptar"
                        // Por simplicidad, asumimos "Aceptar" y la foto ya está en fotoUri
                        Toast.makeText(this, "Foto capturada!", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(this, "Captura de foto cancelada.", Toast.LENGTH_SHORT).show();
                        fotoUri = null; // Limpiar URI si se cancela
                        currentPhotoPath = null;
                        ivFotoPreview.setVisibility(View.GONE);
                    }
                });

        // Inicializar el ActivityResultLauncher para permisos
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                permissions -> {
                    boolean cameraGranted = permissions.getOrDefault(Manifest.permission.CAMERA, false);
                    // El permiso de escritura es opcional dependiendo de la versión de Android y cómo guardes
                    // boolean storageGranted = permissions.getOrDefault(Manifest.permission.WRITE_EXTERNAL_STORAGE, true);

                    if (cameraGranted) {
                        lanzarIntentCamara();
                    } else {
                        Toast.makeText(this, "Permiso de cámara denegado.", Toast.LENGTH_SHORT).show();
                    }
                });


        btnTomarFoto.setOnClickListener(v -> {
            solicitarPermisoYTomarFoto();
        });

        btnGuardar.setOnClickListener(v -> {
            guardarDatos();
        });
    }

    private void solicitarPermisoYTomarFoto() {
        String[] permissionsToRequest;
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) { // Android 9 (Pie) o inferior
            permissionsToRequest = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        } else {
            permissionsToRequest = new String[]{Manifest.permission.CAMERA};
        }

        boolean allPermissionsGranted = true;
        for (String permission : permissionsToRequest) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        if (allPermissionsGranted) {
            lanzarIntentCamara();
        } else {
            requestPermissionLauncher.launch(permissionsToRequest);
        }
    }

    private File crearArchivoImagen() throws IOException {
        // Crear un nombre de archivo de imagen único
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES); // Directorio específico de la app

        // Asegurarse de que el directorio exista
        if (storageDir != null && !storageDir.exists()){
            if (!storageDir.mkdirs()){
                Log.d("AppCamara", "failed to create directory");
                throw new IOException("Failed to create directory for image");
            }
        }

        File image = File.createTempFile(
                imageFileName,  /* prefijo */
                ".jpg",         /* sufijo */
                storageDir      /* directorio */
        );

        // Guardar la ruta del archivo para usarla con ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }


    private void lanzarIntentCamara() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Asegurarse de que haya una actividad de cámara para manejar el intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Crear el File donde debería ir la foto
            File photoFile = null;
            try {
                photoFile = crearArchivoImagen();
            } catch (IOException ex) {
                // Error al crear el File
                Log.e("AppCamara", "Error creando archivo de imagen", ex);
                Toast.makeText(this, "Error al preparar la foto.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Continuar solo si el File fue creado exitosamente
            if (photoFile != null) {
                // Para Android 7.0 (API 24) y superior, necesitas usar FileProvider
                fotoUri = FileProvider.getUriForFile(this,
                        getApplicationContext().getPackageName() + ".provider", // Debe coincidir con authorities en Manifest
                        photoFile);
                takePictureLauncher.launch(fotoUri);
            }
        } else {
            Toast.makeText(this, "No se encontró aplicación de cámara.", Toast.LENGTH_SHORT).show();
        }
    }

    private void guardarDatos() {
        String nombre = etNombre.getText().toString().trim();
        String apellidos = etApellidos.getText().toString().trim();
        String correo = etCorreo.getText().toString().trim();
        String grupo = etGrupo.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(apellidos) || TextUtils.isEmpty(correo) || TextUtils.isEmpty(grupo)) {
            Toast.makeText(this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (fotoUri == null) {
            Toast.makeText(this, "Por favor, tome una foto.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, DisplayActivity.class);
        intent.putExtra("NOMBRE", nombre);
        intent.putExtra("APELLIDOS", apellidos);
        intent.putExtra("CORREO", correo);
        intent.putExtra("GRUPO", grupo);
        intent.putExtra("FOTO_URI", fotoUri.toString()); // Pasar la URI de la foto como String

        startActivity(intent);
    }

    // Manejo del resultado del permiso (ya cubierto por requestPermissionLauncher)
    // No es necesario sobreescribir onRequestPermissionsResult si usas ActivityResultLauncher
}
