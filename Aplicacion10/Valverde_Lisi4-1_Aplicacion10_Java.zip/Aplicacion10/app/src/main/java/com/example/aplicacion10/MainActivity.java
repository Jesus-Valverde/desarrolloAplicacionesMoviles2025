package com.example.aplicacion10;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void abrirApp01(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion01", "com.example.aplicacion01.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp02(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion02", "com.example.aplicacion02.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp03(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion03", "com.example.aplicacion03.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp04(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion04", "com.example.aplicacion04.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp05(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion05", "com.example.aplicacion05.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp06(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion06", "com.example.aplicacion06.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp07(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion07", "com.example.aplicacion07.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp08(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion08", "com.example.aplicacion08.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirApp09(View view) {
        Intent intent = new Intent();
        intent.setClassName("com.example.aplicacion09", "com.example.aplicacion09.MainActivity");

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show();
        }
    }
}